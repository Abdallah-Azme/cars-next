globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/6ef90efc9ef0b6d7.js",
    "static/chunks/37a97314f1b17b22.js",
    "static/chunks/25d4803ec0864a27.js",
    "static/chunks/aee6c7720838f8a2.js",
    "static/chunks/82abf2d65f5428ae.js",
    "static/chunks/turbopack-b0b07bef4f9fa63e.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];