var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/img/route.js")
R.c("server/chunks/[root-of-the-server]__d12d9c6b._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_next-internal_server_app_api_img_route_actions_1f86f7fb.js")
R.m(25895)
module.exports=R.m(25895).exports
