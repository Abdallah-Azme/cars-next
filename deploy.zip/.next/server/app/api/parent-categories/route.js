var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/parent-categories/route.js")
R.c("server/chunks/[root-of-the-server]__fe5cc4ed._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/node_modules_next_f5199d09._.js")
R.c("server/chunks/_next-internal_server_app_api_parent-categories_route_actions_5c2e30b3.js")
R.m(3888)
module.exports=R.m(3888).exports
