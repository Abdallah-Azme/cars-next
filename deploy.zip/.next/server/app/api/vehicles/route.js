var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/vehicles/route.js")
R.c("server/chunks/[root-of-the-server]__80522381._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/node_modules_next_f5199d09._.js")
R.c("server/chunks/_next-internal_server_app_api_vehicles_route_actions_7bc5da8c.js")
R.m(40874)
module.exports=R.m(40874).exports
