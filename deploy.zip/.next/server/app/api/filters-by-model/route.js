var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/filters-by-model/route.js")
R.c("server/chunks/[root-of-the-server]__ac1610c7._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/node_modules_next_f5199d09._.js")
R.c("server/chunks/_next-internal_server_app_api_filters-by-model_route_actions_5708561c.js")
R.m(689)
module.exports=R.m(689).exports
