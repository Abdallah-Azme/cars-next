var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/by-model-type/route.js")
R.c("server/chunks/[root-of-the-server]__32363056._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/node_modules_next_f5199d09._.js")
R.c("server/chunks/_next-internal_server_app_api_by-model-type_route_actions_47d0e9bc.js")
R.m(25045)
module.exports=R.m(25045).exports
