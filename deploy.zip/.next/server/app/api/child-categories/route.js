var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/child-categories/route.js")
R.c("server/chunks/[root-of-the-server]__8b2f7b44._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/node_modules_next_f5199d09._.js")
R.c("server/chunks/_next-internal_server_app_api_child-categories_route_actions_f6b78a59.js")
R.m(17091)
module.exports=R.m(17091).exports
