var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/models-by-category/route.js")
R.c("server/chunks/[root-of-the-server]__4bfe5bce._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/node_modules_next_f5199d09._.js")
R.c("server/chunks/_next-internal_server_app_api_models-by-category_route_actions_e6f177e6.js")
R.m(49122)
module.exports=R.m(49122).exports
