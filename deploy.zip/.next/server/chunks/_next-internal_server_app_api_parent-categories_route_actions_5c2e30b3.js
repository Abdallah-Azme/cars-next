module.exports=[82058,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_parent-categories_route_actions_5c2e30b3.js.map