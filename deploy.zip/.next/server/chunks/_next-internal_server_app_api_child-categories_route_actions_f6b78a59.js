module.exports=[85584,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_child-categories_route_actions_f6b78a59.js.map