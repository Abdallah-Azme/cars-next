module.exports=[11066,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_models-by-category_route_actions_e6f177e6.js.map