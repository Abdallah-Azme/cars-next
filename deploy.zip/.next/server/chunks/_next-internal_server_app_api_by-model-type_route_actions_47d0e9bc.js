module.exports=[90811,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_by-model-type_route_actions_47d0e9bc.js.map